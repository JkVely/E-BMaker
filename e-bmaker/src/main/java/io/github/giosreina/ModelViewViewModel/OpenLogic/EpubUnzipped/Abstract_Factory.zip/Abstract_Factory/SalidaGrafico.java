package Abstract_Factory;
import javax.swing.*;
import java.awt.*;

/**
 * Aplicación gráfica simple que muestra únicamente un texto (String)
 */
public class SalidaGrafico extends JFrame implements ProductoSalida {
    
    private String texto = "¡Hola Mundo!";
    
    /**
     * Constructor de la aplicación
     */
    public void enviar(String mensaje) {
        // Configuración básica de la ventana
        setTitle(mensaje);
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Centra la ventana en la pantalla
        
        // Crear un panel personalizado para mostrar el texto
        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                dibujarTexto(g);
            }
        };
        
        // Configurar el panel
        panel.setBackground(Color.WHITE);
        
        // Agregar el panel a la ventana
        add(panel);
    }
    
    /**
     * Método para dibujar el texto en el panel
     */
    private void dibujarTexto(Graphics g) {
        // Configurar el estilo del texto
        Font fuente = new Font("Arial", Font.BOLD, 24);
        g.setFont(fuente);
        g.setColor(Color.BLUE);
        
        // Calcular la posición para centrar el texto
        FontMetrics metrics = g.getFontMetrics(fuente);
        int x = (getWidth() - metrics.stringWidth(texto)) / 2;
        int y = ((getHeight() - metrics.getHeight()) / 2) + metrics.getAscent();
        
        // Dibujar el texto
        g.drawString(texto, x, y);
    }
}