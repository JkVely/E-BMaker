package Abstract_Factory;
public class SalidaTerminal implements ProductoSalida {
    String mensaje;
    public void enviar(String mensaje) {
        this.mensaje = mensaje;
        System.out.println(mensaje);
    }
}