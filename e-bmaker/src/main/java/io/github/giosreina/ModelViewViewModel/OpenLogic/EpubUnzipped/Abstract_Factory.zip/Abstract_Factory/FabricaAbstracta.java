package Abstract_Factory;
public abstract class FabricaAbstracta {
    public abstract ProductoSalida crearSalida();
    public abstract ProductoEntrada crearEntrada();
}