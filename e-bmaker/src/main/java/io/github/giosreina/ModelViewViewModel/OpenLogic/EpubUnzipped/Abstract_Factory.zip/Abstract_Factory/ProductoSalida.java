package Abstract_Factory;
public interface ProductoSalida{
    public abstract void enviar(String mensaje);
}