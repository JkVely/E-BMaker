package Abstract_Factory;
import java.io.IOException;
public abstract class ProductoEntrada {
    public abstract String capturar() throws IOException;
}