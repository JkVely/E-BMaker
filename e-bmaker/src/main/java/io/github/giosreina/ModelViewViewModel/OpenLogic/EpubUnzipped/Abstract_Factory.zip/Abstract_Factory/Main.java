package Abstract_Factory;
import java.io.*;
public class Main {
    public static void main(String[] args) throws IOException {
        // Crear una instancia de EntradaArchivo
        EntradaArchivo entradaArchivo = new EntradaArchivo();
        
        entradaArchivo.capturar();
    }
}
